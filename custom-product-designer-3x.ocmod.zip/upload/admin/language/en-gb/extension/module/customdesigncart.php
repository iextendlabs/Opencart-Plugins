<?php
// Heading
$_['heading_title']    = 'Custom Product Designer';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Custom Product Designer!';
$_['text_edit']        = 'Edit Custom Product Designer';

// Entry
$_['entry_status']     = 'Status';
$_['entry_iframe_url']     = 'iFrame URL';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Custom Product Designer!';